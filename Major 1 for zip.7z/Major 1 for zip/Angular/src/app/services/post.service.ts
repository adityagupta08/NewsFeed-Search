import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/Http';

import { Observable } from 'rxjs';
import {IPost} from '../post/IPost';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  public _urlPosts = 'http://localhost:8080/rest/api/load'
   public _urlCreate = 'http://localhost:8080/rest/api/users/createPosts/saurabhgupta';
   public _urlLikePost = 'http://localhost:8080/getLike';
  public _urlunLikePost = 'http://localhost:8080/removeLike';   
  constructor(private http:HttpClient) { }


  getPosts():Observable<any[]>{
    return this.http.get<any[]>(this._urlPosts);
  }
  
  addPosts(value):Observable<any[]>{
    return this.http.patch<any[]>(this._urlCreate,value)
  }

  addLike(objValue):Observable<any[]>{
    return this.http.post<any[]>(this._urlLikePost,objValue);
  }

  removeLike(objValue):Observable<any[]>{
    return this.http.post<any[]>(this._urlunLikePost,objValue);
  }

   countlikes(pName,pId):Observable<IPost[]>{
   return this.http.get<IPost[]>('http://localhost:8080/getLikesdetails/'+pName+'/'+pId)
}
}
