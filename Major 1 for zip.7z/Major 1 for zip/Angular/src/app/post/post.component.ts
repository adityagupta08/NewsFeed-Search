import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor(private _service: PostService) { }
  linkedIn: any = []
  public CreatePosts;
  public strObj;
   public likesNames=[];
  i:number;
  data=[];
  islike:boolean[]= []
  ngOnInit() {

    this.getPosts();

    
  }
  getPosts() {
    this._service.getPosts().subscribe(data => {this.linkedIn.push(data)
      console.log(this.linkedIn);
    for(var i=0;i<this.linkedIn[0].length;i++)
    {
        if(this.linkedIn[0][i].likes.length==0)
      {
        this.islike[i]=false;
      }
    for(var j=0;j<this.linkedIn[0][i].likes.length;j++)
     {
     if(this.linkedIn[0][i].likes[j].likedBy=='hsagarthegr8')////Need to Enter username here
     {
       this.islike[i]=true;
      }
     
      else
      {
        this.islike[i]=false;
      }
     }
    }
  });
    
  }

  addPosts(value) {
    this.linkedIn = [];
    this.strObj = '{"content":"' + value + '"}'
    this._service.addPosts(JSON.parse(this.strObj)).subscribe(data => this.linkedIn.push(data));
    
    
  }

  likePost(uName, postId, i){
    {
      if(this.islike[i]==false)
      {
      this.islike[i]=!this.islike[i];
    ////  this.color="blue";
      this.strObj = '{"userName":"hsagarthegr8","postedBy":"'+uName +'","postId":"'+ postId+'"}';//Need to Enter username here
      this.linkedIn[0][i].likes.push(JSON.parse(this.strObj));
      this._service.addLike(JSON.parse(this.strObj)).subscribe((data:any)=>{});
    }
    else if(this.islike[i]==true)
    {
      this.islike[i]=!this.islike[i];
     // this.color="black";
      this.strObj = '{"userName":"hsagarthegr8","postedBy":"'+uName +'","postId":"'+ postId+'"}';//Need to Enter username here
      this.linkedIn[0][i].likes.pop(JSON.parse(this.strObj));
      this._service.removeLike(JSON.parse(this.strObj)).subscribe((data:any)=>{});
     
    }
     this.likedetails(uName,postId)
    }
  }

  likedetails(uName,postId)
  {
     return this._service.countlikes(uName,postId).subscribe((d)=>{this.data=d});
  }

   likes(id:string){
    this.likesNames=[];
    for(let index of this.linkedIn[0]){
       if(index.postId == id){
          this.likesNames.push(index.likes)
          
        }
      }
      
    }
  }

