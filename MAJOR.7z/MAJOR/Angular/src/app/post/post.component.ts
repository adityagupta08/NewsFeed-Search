import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor(private _service: PostService) { }
  linkedIn: any = []
  public CreatePosts;
  public strObj;
  ngOnInit() {

    this.getPosts();
  }
  getPosts() {
    this._service.getPosts().subscribe(data => this.linkedIn.push(data));
    console.log(this.linkedIn);
  }

  addPosts(value) {
    this.linkedIn = [];
    this.strObj = '{"content":"' + value + '"}'
    this._service.addPosts(JSON.parse(this.strObj)).subscribe(data => this.linkedIn.push(data));
  }

  likePost(uName, postId, i){
    console.log(uName, postId, i); //jisne post kiya tha..
    this.strObj = '{"userName":"hsagarthegr8","postedBy":"'+uName +'","postId":"'+ postId+'"}';
    console.log(this.linkedIn[0][i]);
    console.log(JSON.parse(this.strObj));
    this.linkedIn[0][i].likes.push(JSON.parse(this.strObj));
    this._service.addLike(JSON.parse(this.strObj)).subscribe(data=> console.log());
  }

}
