import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/Http';

import { Observable } from 'rxjs';
import {IPost} from './post/IPost';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  public _url = 'http://localhost:8080/rest/api/load'

  constructor(private http:HttpClient) { }


  getPosts():Observable<any>{
    return this.http.get<any>(this._url);
  }
}
