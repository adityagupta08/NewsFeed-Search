import { Component, OnInit } from '@angular/core';
import {PostService} from '../post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor(private _service:PostService) { }
  linkedIn:any=[]
  ngOnInit() {

    this.getPosts();
  }
  getPosts() {
    this._service.getPosts().subscribe(data => this.linkedIn.push(data));
    console.log(this.linkedIn)
    return false;
  }

}
