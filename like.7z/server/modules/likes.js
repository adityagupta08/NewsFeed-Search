const express = require('express');
const app = express();

const Dao = require('./data-access');
const dao = new Dao();

/*
*Description:when the user clicks on 'Like':Based on postuserId and postid
*       the name of the particular user will be added to the like section
*       of that particular post along with time.
*(postuserId,postid,username,timestamp)
*@author (P.Puneeth,Sajida)
*@param {Database collection} collections 
*@param {number} postuserId
*@param {number} postid
*@param {string} username
*@param {date} timestamp
*@returns {object} result
*/

/*
*Description:when the user again clicks on 'Like':Based on postuserId and postid
*       the name of the particular user will be removed from the like section
*       of that particular post along with time.
*(postuserId,postid,username,timestamp)
*@author (P.Puneeth,Sajida)
*@param {Database collection} collections 
*@param {number} postuserId
*@param {number} postid
*@param {string} username
*@param {date} timestamp
*@returns {object} result
*/


class likes {

    async getLike(collections,name,time) {
       let result = await dao.update(collections, {$and:[{"userId":1001},{"posts.postid":1}]},{$push:{"posts.$.likes":{"likedBy":name,"timestamp":time}}});
        return (result);
    }

    async removeLike(collections,name,time) {
        
       let result = await dao.update(collections, {$and:[{"userId":1001},{"posts.postid":1}]},{$pull:{"posts.$.likes":{"likedBy":name,"timestamp":time}}});
        return (result);
    }
}

module.exports = likes

