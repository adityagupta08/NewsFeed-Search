const express = require('express')
const app = express()
const likes = require('./modules/likes');
const Dao = require('./modules/data-access')
const connection = new likes();
const dao = new Dao()
var parser = require("body-parser");
app.use(parser.json());
const connCollection = "users";




app.post('/getLike', async (req, res) => {
    let result
    try {
        var store=req.body;
        result = await connection.getLike(connCollection,store.name,store.time)
    } 
    catch (err) {
        result = {err:err}
    } 
    res.send(result)
})

app.post('/removeLike', async (req, res) => {
    let result
    try {
        var store=req.body;
        result = await connection.removeLike(connCollection,store.name,store.time)
    } 
    catch (err) {
        result = {err:err}
    } 
    res.send(result)
})


app.listen('8080', () => console.log('Listening on port 8080'))



/*
using aggregate
app.get('/rest/api/users/get/', async (req, res) => {
    let result = await dao.find("users",[{$project:{"posts.likes.likedBy":1}}])
    res.send(result)
})

app.patch('/rest/api/users/update/', async (req, res) => {
    let result
    try {
        result = await dao.update("users",{$and:[{"userId":1000},{"posts.postid":1}]},{$push:{"posts.0.likes":{"likedBy":"Reddy","timestamp":"2015-02-28T00:00:00Z"}}})
    } 
    catch (err) {
        result = {err:err}
    } 
    res.send(result)
})


app.patch('/rest/api/users/update/', async (req, res) => {
    let result
    try {
        result = await dao.update("users",{$and:[{"userId":1000},{"posts.postid":1}]},{$pull:{"posts.0.likes":{"likedBy":"Reddy","timestamp":"2015-02-28T00:00:00Z"}}})
    } 
    catch (err) {
        result = {err:err}
    } 
    res.send(result)
})

using find
app.get('/rest/api/users/get/', async (req, res) => {
    let result = await dao.find("users",{"posts.likes.likedBy":"Banu"}}])
    res.send(result)
})

app.get('/rest/api/users/get/', async (req, res) => {
    let result = await dao.find(connCollection,[{$match:{$and:[{"userId":1001},{"posts.postid":1}]}},{$group:{_id:"$posts.likes.likedBy","count":{$sum:1}}}])
    console.log(result)
    res.send(result)
})


*/

