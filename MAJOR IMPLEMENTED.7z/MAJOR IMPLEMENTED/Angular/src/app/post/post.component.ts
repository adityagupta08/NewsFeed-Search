import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';
import { ReversePipe } from '../reverse.pipe'

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  constructor(private _service: PostService) {

  }
  public edit: string = "";
  linkedIn: any = []
  public CreatePosts;
  public strObj;
  public likesCount: number;
  public likesNames = []
  name: any = [];
  content: any = [];
  public  indexPost;

  ngOnInit() {
    this.getPosts();
  }
  getPosts() {
    this._service.getPosts().subscribe(data => { this.linkedIn.push(data); console.log(this.linkedIn) });
  }

  addPosts(value) {
    this.linkedIn = [];
    console.log(value);
    this.strObj = '{"content":"' + value + '"}'
    console.log(this.strObj)
    this._service.addPosts(JSON.parse(this.strObj)).subscribe(data => this.linkedIn.push(data));
  }
 
  editPosts() {
    this.linkedIn = [];
    this.strObj = '{"content":"' + this.edit + '"}'
    this._service.editPosts(this.indexPost, JSON.parse(this.strObj)).subscribe(data => this.linkedIn.push(data));

  }
  callModal(i) {
    this.edit = this.linkedIn[0][i].content;
    this.indexPost = this.linkedIn[0][i].postId;
  }
  deletePosts(postId) {
    this.linkedIn = [];
    this._service.deletePosts(postId).subscribe(data => this.linkedIn.push(data));
  }

  likePost(uName, postId, i) {
    console.log(uName, postId, i); //jisne post kiya tha..
    this.strObj = '{"userName":"hsagarthegr8","postedBy":"' + uName + '","postId":"' + postId + '"}';
    console.log(this.linkedIn[0][1].timestamp);
    console.log(JSON.parse(this.strObj));
    this.linkedIn[0][i].likes.push(JSON.parse(this.strObj));
    this._service.addLike(JSON.parse(this.strObj)).subscribe(data => console.log());
  }

  DisplayLikes(id: string) {
    this.likesNames = [];

    for (let index of this.linkedIn[0]) {

      if (index.postId == id) {
        this.likesCount = index.likes.length;
        this.likesNames.push(index.likes[0])
      }
    }



  }



  clearData() {
    this.content = '';
    this.name = '';

  }

  postCommentData(username, postid, index) {

    console.log(username)
    //this.name we have to userName of person who logged in from session
    this.strObj = '{"name":"' + this.name[index] + '","content":"' +
      this.content[index] + '"}';
    console.log(this.strObj);
    return this._service.postComment(username, postid, JSON.parse(this.strObj)).subscribe((d: any) => {
      this.linkedIn[0][index].comments = d[0].posts.comments
      console.log(this.linkedIn.comments)
      this.clearData();
    });
  }

}
